var searchData=
[
  ['unknown_5f_0',['unknown_',['../classParams.html#a6bee2b60bff0fd80302f88bebbe92d00',1,'Params']]],
  ['username_1',['Username',['../classExiv2_1_1Uri.html#ab7524b043a2747f81f63d17efd79ba89',1,'Exiv2::Uri']]]
];
