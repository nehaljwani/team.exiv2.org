var searchData=
[
  ['value_0',['Value',['../classExiv2_1_1Value.html',1,'Exiv2']]],
  ['valuetype_1',['ValueType',['../classExiv2_1_1ValueType.html',1,'Exiv2']]]
];
