/* config.h. Should be a generated file, eventually... */

/* Define to the full name of this package. */
#define PACKAGE_NAME "Exiv2"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "Exiv2 version 0.4"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "exiv2"

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.4"
