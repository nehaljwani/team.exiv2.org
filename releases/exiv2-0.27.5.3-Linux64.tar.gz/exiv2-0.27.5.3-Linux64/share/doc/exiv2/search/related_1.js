var searchData=
[
  ['setvalue_4483',['setValue',['../classExiv2_1_1Exifdatum.html#a8e1c4b0d24e694e91ebc3f8517365bcd',1,'Exiv2::Exifdatum']]]
];
