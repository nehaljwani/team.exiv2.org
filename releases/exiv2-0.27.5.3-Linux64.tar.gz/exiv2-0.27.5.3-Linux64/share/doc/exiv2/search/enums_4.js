var searchData=
[
  ['envar_4418',['EnVar',['../namespaceExiv2.html#a5dea113f005c36569d07fa669efcd782',1,'Exiv2']]],
  ['errorcode_4419',['ErrorCode',['../namespaceExiv2.html#a2f8222633119f427c209fe2ae0bc340b',1,'Exiv2']]]
];
