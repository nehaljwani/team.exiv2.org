var searchData=
[
  ['l2data_2786',['l2Data',['../namespaceExiv2.html#a34f6d26c2d1cccbcda6e49f606675645',1,'Exiv2']]],
  ['langaltvalue_2787',['LangAltValue',['../classExiv2_1_1LangAltValue.html#aa6e57338d68ad7a79567e7d4271ce74c',1,'Exiv2::LangAltValue::LangAltValue()'],['../classExiv2_1_1LangAltValue.html#abf8c25b7c35adcd521ec83bacd0b09fd',1,'Exiv2::LangAltValue::LangAltValue(const std::string &amp;buf)']]],
  ['lensname_2788',['lensName',['../namespaceExiv2.html#ad032c255e7a9c18706051b3cd1e4ec04',1,'Exiv2']]],
  ['level_2789',['level',['../classExiv2_1_1LogMsg.html#acc66b40a37a56cdd2d173e11d61820fc',1,'Exiv2::LogMsg']]],
  ['lightsource_2790',['lightSource',['../namespaceExiv2.html#a196bda962e3befbc32bd6a9eea811b31',1,'Exiv2']]],
  ['listhandler_2791',['listHandler',['../classExiv2_1_1RiffVideo.html#a17e7e982c4133f27658a1419c272a31c',1,'Exiv2::RiffVideo']]],
  ['loadstack_2792',['loadStack',['../classExiv2_1_1Internal_1_1CrwMap.html#ae8e294d1437f8087521e7566e298f79b',1,'Exiv2::Internal::CrwMap']]],
  ['locateiptcirb_2793',['locateIptcIrb',['../structExiv2_1_1Photoshop.html#ac34205eee36512a0626bddbb462a0620',1,'Exiv2::Photoshop']]],
  ['locateirb_2794',['locateIrb',['../structExiv2_1_1Photoshop.html#a31fe5a20fe69912e2bb2f87b40c116c6',1,'Exiv2::Photoshop']]],
  ['locatepreviewirb_2795',['locatePreviewIrb',['../structExiv2_1_1Photoshop.html#a98e277e6b49a095bf931952a6cecf16f',1,'Exiv2::Photoshop']]],
  ['logmsg_2796',['LogMsg',['../classExiv2_1_1LogMsg.html#aef46b169c328eecf0b83886ef8b9ea9f',1,'Exiv2::LogMsg']]],
  ['lookupnsregistry_2797',['lookupNsRegistry',['../classExiv2_1_1XmpProperties.html#a899a34dc5d27750e7e6ece0a249d1bcc',1,'Exiv2::XmpProperties']]],
  ['ltrim_2798',['ltrim',['../namespaceExiv2_1_1Internal.html#af2a2a539af557cc380199b41407f6cb9',1,'Exiv2::Internal']]]
];
