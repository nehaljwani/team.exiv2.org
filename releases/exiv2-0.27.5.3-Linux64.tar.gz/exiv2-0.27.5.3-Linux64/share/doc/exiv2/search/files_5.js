var searchData=
[
  ['iptc_2ehpp_2420',['iptc.hpp',['../iptc_8hpp.html',1,'']]]
];
