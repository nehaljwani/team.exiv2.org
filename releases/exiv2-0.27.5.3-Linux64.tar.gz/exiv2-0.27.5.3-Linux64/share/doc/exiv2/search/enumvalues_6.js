var searchData=
[
  ['kerdataareavaluetoolarge_4451',['kerDataAreaValueTooLarge',['../namespaceExiv2.html#a2f8222633119f427c209fe2ae0bc340bace2b02c4983f44c3584b85de7a861c1c',1,'Exiv2']]],
  ['kervaluetoolarge_4452',['kerValueTooLarge',['../namespaceExiv2.html#a2f8222633119f427c209fe2ae0bc340ba5d37fc6fe341311a3cc5d752fd222fec',1,'Exiv2']]]
];
