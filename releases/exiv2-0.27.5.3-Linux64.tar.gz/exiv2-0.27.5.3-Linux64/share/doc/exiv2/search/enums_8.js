var searchData=
[
  ['level_4423',['Level',['../classExiv2_1_1LogMsg.html#af72a9026cffe2536ae475e1c31e7ff70',1,'Exiv2::LogMsg']]]
];
