var searchData=
[
  ['longvalue_4376',['LongValue',['../namespaceExiv2.html#a47f8d64316779977c1869da776c26b6e',1,'Exiv2']]]
];
