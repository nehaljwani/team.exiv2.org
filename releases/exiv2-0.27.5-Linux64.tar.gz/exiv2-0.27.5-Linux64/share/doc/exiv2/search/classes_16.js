var searchData=
[
  ['webpimage_2385',['WebPImage',['../classExiv2_1_1WebPImage.html',1,'Exiv2']]]
];
