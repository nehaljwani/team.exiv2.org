var searchData=
[
  ['txtchunktype_4433',['TxtChunkType',['../classExiv2_1_1Internal_1_1PngChunk.html#a9a05f1f7d1b88f8e869813f6b318fd35',1,'Exiv2::Internal::PngChunk']]],
  ['typeid_4434',['TypeId',['../namespaceExiv2.html#a5153319711f35fe81cbc13f4b852450c',1,'Exiv2']]]
];
