var searchData=
[
  ['rational_4389',['Rational',['../namespaceExiv2.html#a95756f3f7fa19103f83addf5fa088a30',1,'Exiv2']]],
  ['rationalvalue_4390',['RationalValue',['../namespaceExiv2.html#ab2a69ae1200f28233d89237bcefe952f',1,'Exiv2']]]
];
