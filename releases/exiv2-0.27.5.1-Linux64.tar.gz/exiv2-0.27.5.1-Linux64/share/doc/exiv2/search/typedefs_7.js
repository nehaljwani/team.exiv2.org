var searchData=
[
  ['handler_4369',['Handler',['../classExiv2_1_1LogMsg.html#a7058654225955500dc09e31d0834aed1',1,'Exiv2::LogMsg']]]
];
