var searchData=
[
  ['metadataid_4424',['MetadataId',['../namespaceExiv2.html#acca494c8cf80f3ac8a804e1b54afffca',1,'Exiv2::MetadataId()'],['../exiv2app_8hpp.html#a4d2c7e9b6e47d52f540831c5b5c9b2bf',1,'MetadataId():&#160;exiv2app.hpp']]]
];
