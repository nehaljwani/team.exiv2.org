var searchData=
[
  ['gifimage_2232',['GifImage',['../classExiv2_1_1GifImage.html',1,'Exiv2']]],
  ['groupinfo_2233',['GroupInfo',['../structExiv2_1_1GroupInfo.html',1,'Exiv2']]]
];
