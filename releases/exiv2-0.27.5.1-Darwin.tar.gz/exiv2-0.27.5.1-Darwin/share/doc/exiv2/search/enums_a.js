var searchData=
[
  ['offsetid_4478',['OffsetId',['../classExiv2_1_1Internal_1_1OffsetWriter.html#aaacdcd1d3c2a9cabb6ee53dca00d7b66',1,'Exiv2::Internal::OffsetWriter']]],
  ['opmode_4479',['OpMode',['../classExiv2_1_1FileIo_1_1Impl.html#a393f5d1d8ba1ef27f78661a2b2c1c8f9',1,'Exiv2::FileIo::Impl']]]
];
