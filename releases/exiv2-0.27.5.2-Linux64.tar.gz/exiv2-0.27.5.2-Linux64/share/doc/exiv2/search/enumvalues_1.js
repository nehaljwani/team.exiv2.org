var searchData=
[
  ['comment_4442',['comment',['../namespaceExiv2.html#a5153319711f35fe81cbc13f4b852450ca98944819f3c9921109af5f0a39fcfa34',1,'Exiv2']]],
  ['cr2rawifdoffset_4443',['cr2RawIfdOffset',['../classExiv2_1_1Internal_1_1OffsetWriter.html#aaacdcd1d3c2a9cabb6ee53dca00d7b66a9cd54e49efc4b1dfaf2afdf478cd7369',1,'Exiv2::Internal::OffsetWriter']]]
];
