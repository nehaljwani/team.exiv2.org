var searchData=
[
  ['isexvtype_4481',['isExvType',['../classExiv2_1_1ExvImage.html#a5e9a3ffa89d4c0f6332aa12460f948be',1,'Exiv2::ExvImage']]],
  ['isjpegtype_4482',['isJpegType',['../classExiv2_1_1JpegImage.html#ae19b36616ee5d8202ab703922fd38278',1,'Exiv2::JpegImage']]]
];
