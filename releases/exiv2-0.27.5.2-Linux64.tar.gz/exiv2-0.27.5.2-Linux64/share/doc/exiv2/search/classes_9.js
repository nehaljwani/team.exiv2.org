var searchData=
[
  ['jp2image_2248',['Jp2Image',['../classExiv2_1_1Jp2Image.html',1,'Exiv2']]],
  ['jpegbase_2249',['JpegBase',['../classExiv2_1_1JpegBase.html',1,'Exiv2']]],
  ['jpegimage_2250',['JpegImage',['../classExiv2_1_1JpegImage.html',1,'Exiv2']]]
];
