var searchData=
[
  ['ini_5fhandler_4370',['ini_handler',['../namespaceExiv2.html#a35bf081c63f6036c8a151e80eeeaea19',1,'Exiv2']]],
  ['ini_5freader_4371',['ini_reader',['../namespaceExiv2.html#a261ac8663b18b02a81fc0662f95a7b56',1,'Exiv2']]],
  ['iptcmetadata_4372',['IptcMetadata',['../namespaceExiv2.html#a5caa9cbded318bf7d22a2d219c3d45f4',1,'Exiv2']]],
  ['isthistypefct_4373',['IsThisTypeFct',['../namespaceExiv2.html#aafd83ca9221779c4f95dc17261966b22',1,'Exiv2']]],
  ['iterator_4374',['iterator',['../classExiv2_1_1ExifData.html#a02e2a2acb4cfeb0f7755c1a45f94106f',1,'Exiv2::ExifData::iterator()'],['../classExiv2_1_1IptcData.html#a0d53776cd2f36e63fff78c8f142a7caf',1,'Exiv2::IptcData::iterator()'],['../classExiv2_1_1ValueType.html#a38d2c3d37e48bd5b3c00f3693e493ad8',1,'Exiv2::ValueType::iterator()'],['../classExiv2_1_1XmpData.html#a6ad054efbea675843895e3f74c3c1923',1,'Exiv2::XmpData::iterator()']]]
];
