var searchData=
[
  ['date_4444',['date',['../namespaceExiv2.html#a5153319711f35fe81cbc13f4b852450ca0c347d8ddbbad9440f9bb6db8a06fa45',1,'Exiv2']]],
  ['directory_4445',['directory',['../namespaceExiv2.html#a5153319711f35fe81cbc13f4b852450cafc7cbf89ae7c64de808dc3611b2a880f',1,'Exiv2']]]
];
