var searchData=
[
  ['ifdid_4422',['IfdId',['../namespaceExiv2_1_1Internal.html#ab61a3dc9c8db85c29abf3f7443b25db0',1,'Exiv2::Internal']]]
];
