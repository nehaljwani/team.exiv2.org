var searchData=
[
  ['sectionid_4432',['SectionId',['../namespaceExiv2_1_1Internal.html#a42c2915d6eb0c870b5c2b233c8076037',1,'Exiv2::Internal']]]
];
